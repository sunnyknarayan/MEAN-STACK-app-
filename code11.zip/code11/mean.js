var express = require('express'),
app = express();
var bodyparser = require('body-parser');
var session = require('client-sessions');

app.use(express.static('public'));
app.use(bodyparser.json());  
//app.use(express.cookieParser());
//app.use(express.session({secret:'spider'}));

var MongoClient = require('mongodb').MongoClient;
var conn_str = 'mongodb://localhost:27017/test1';


app.use(
    session({
        cookieName:'session',
        secret : 'marlabs_sess_secret_key',
       // duration: 30 * 60 * 1000,
        //activeDuration : 5 * 60 * 1000,
       resave : true,
       saveUninitialized : true,
        //store : store
    })
);


app.post('/login',function(req,res){
   
    
    if(req.body.username == "admin" && req.body.password == "admin"){
        console.log("credentials correct");
      
     //  req.session.isloggedIn = true; 

     //setting session
       req.session.ssn = req.body.username;
       console.log(req.session.ssn);

    //    res.json({result:true, sessiondata : req.session.ssn});
       // res.json(true);

       res.json({result:true});
    }else{
        //req.session.isLoggedIn = false;
        res.json({result:false});
    }
});

app.get('/', function(req, res) {  
res.sendFile(__dirname+'/mean.html');
});
app.get('/welcome', function(req, res) {
res.sendFile(__dirname+'views/welcome.html');
});



///// data inserting at mongodb
app.post('/saved',function(req,res,next) 
{
  MongoClient.connect(conn_str,function(err,db)
  {
//console.log("connected to server");
 db.collection('test').insert(req.body , function(err,res){
       console.log("data inserted into db");
    });
});
});


app.get('/traineedata',function(req,res){
MongoClient.connect(conn_str,function(err,db){
db.collection('test',function(err,t_collection){
    t_collection.find().toArray(function(err,result){
        //console.log(result);
return res.send(result);

    });
});

});
});

app.get('/checkAuth', function(req,res){
    console.log("from mean.js");
    console.log(req.session.ssn);
if(req.session.ssn){
    console.log('checkAuth true');

    res.json({result:true});
} else {
    console.log('checkAuth false');
    res.json({result:false});
}
});
  
app.post('/logout_session', function(req,res,next){
    console.log("session is going to destroy delete");
    
//    req.session.destroy();
var session = require('client-sessions');
    req.session.reset();
    res.redirect('/login');
});

var server_listen = app.listen(3307, function() {
console.log('Server running @ localhost:3307');
});
